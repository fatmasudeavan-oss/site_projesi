from django.urls import path
from core import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('blocks/', views.blocks_page, name='blocks'),
    path('apartments/', views.apartments_page, name='apartments'),
    path('apartments/delete/<int:id>/', views.apartment_delete, name='apartment_delete'),
    path('logout/', views.logout_view, name='logout'),
    path('login/', auth_views.LoginView.as_view(), name='login'),
path('logout/', auth_views.LogoutView.as_view(), name='logout'),
  
    
]