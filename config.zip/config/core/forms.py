from django import forms
from .models import Block, Apartment, Floor

class BlockForm(forms.ModelForm):
    class Meta:
        model = Block
        fields = ['name']


class ApartmentForm(forms.ModelForm):
    class Meta:
        model = Apartment
        fields = ['floor', 'number']

from django import forms
from .models import Resident

class ResidentForm(forms.ModelForm):
    class Meta:
        model = Resident
        fields = ['apartment', 'name', 'phone']

from django import forms
from .models import Request

class RequestForm(forms.ModelForm):
    class Meta:
        model = Request
        fields = ['resident', 'title', 'description', 'status']