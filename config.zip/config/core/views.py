from django.shortcuts import render
from .models import Block, Apartment, Resident, Request

def dashboard(request):
    context = {
        "blocks_count": Block.objects.count(),
        "apartments_count": Apartment.objects.count(),
        "residents_count": Resident.objects.count(),
        "open_requests": Request.objects.filter(status="pending").count(),
        "requests": Request.objects.all().order_by('-id')[:10],
    }
    return render(request, "dashboard.html", context)

from django.shortcuts import render, redirect
from .models import Block, Apartment
from .forms import BlockForm, ApartmentForm

def blocks_page(request):
    form = BlockForm()

    if request.method == "POST":
        form = BlockForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('blocks')

    blocks = Block.objects.all()

    return render(request, "blocks.html", {
        "form": form,
        "blocks": blocks
    })


def apartments_page(request):
    form = ApartmentForm()

    if request.method == "POST":
        form = ApartmentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('apartments')

    apartments = Apartment.objects.all()

    return render(request, "apartments.html", {
        "form": form,
        "apartments": apartments
    })

from django.shortcuts import get_object_or_404, redirect
from .models import Apartment

def apartment_delete(request, id):
    apt = get_object_or_404(Apartment, id=id)
    apt.delete()
    return redirect('apartments')


from django.shortcuts import get_object_or_404, redirect
from .models import Block

def block_delete(request, id):
    block = get_object_or_404(Block, id=id)
    block.delete()
    return redirect('blocks')


from django.shortcuts import render, redirect, get_object_or_404
from .models import Resident
from .forms import ResidentForm

def residents_page(request):
    form = ResidentForm(request.POST or None)

    if request.method == "POST":
        if form.is_valid():
            form.save()
            return redirect('residents')

    residents = Resident.objects.all()

    return render(request, "residents.html", {
        "form": form,
        "residents": residents
    })


def resident_delete(request, id):
    resident = get_object_or_404(Resident, id=id)
    resident.delete()
    return redirect('residents')



from django.shortcuts import render, redirect, get_object_or_404
from .models import Request
from .forms import RequestForm

def requests_page(request):
    form = RequestForm(request.POST or None)

    if request.method == "POST":
        if form.is_valid():
            form.save()
            return redirect('requests')

    requests = Request.objects.all().order_by('-id')

    return render(request, "requests.html", {
        "form": form,
        "requests": requests
    })


def request_delete(request, id):
    req = get_object_or_404(Request, id=id)
    req.delete()
    return redirect('requests')


def request_toggle(request, id):
    req = get_object_or_404(Request, id=id)

    if req.status == "pending":
        req.status = "completed"
    else:
        req.status = "pending"

    req.save()
    return redirect('requests')



from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login





from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User  # Kayıt için bu satır ŞART

# Mevcut dashboard fonksiyonun burada kalsın...

def login_view(request):
    if request.method == 'POST':
        u = request.POST.get('username') 
        p = request.POST.get('password')
        
        user = authenticate(request, username=u, password=p)
        if user is not None:
            login(request, user)
            return redirect('/')
        else:
            # Hatalı girişte ana sayfaya hata koduyla döner
            return redirect('/?error=1')
    return redirect('/')

def register_view(request):
    if request.method == 'POST':
        full_name = request.POST.get('full_name')
        u = request.POST.get('username') # E-posta veya Telefon
        p = request.POST.get('password')
        
        # Bu kullanıcı adı (mail/tel) daha önce alınmış mı?
        if User.objects.filter(username=u).exists():
            return redirect('/?error=user_exists')
        
        # Yeni kullanıcıyı veritabanına ekle
        user = User.objects.create_user(username=u, password=p)
        user.first_name = full_name
        user.save()
        
        # Kayıt biter bitmez kullanıcıyı içeri al (giriş yaptır)
        login(request, user)
        return redirect('/')
    
    return redirect('/')


from django.contrib.auth import logout # Bunu en üste, diğer importların yanına ekle

def logout_view(request):
    logout(request)
    return redirect('/') # Çıkış yaptıktan sonra ana sayfaya döner

from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.shortcuts import redirect


def login_view(request):

    if request.method == "POST":

        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user:
            login(request, user)

    return redirect("/")


def register_view(request):

    if request.method == "POST":

        username = request.POST.get("username")
        password = request.POST.get("password")

        if not User.objects.filter(username=username).exists():

            User.objects.create_user(
                username=username,
                password=password
            )

    return redirect("/")


from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm

def register_view(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()

    return render(request, 'register.html', {'form': form})


from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm

def register_view(request):
    form = UserCreationForm()

    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')

    return render(request, 'register.html', {'form': form})


from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm

def register_view(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()

    return render(request, 'register.html', {'form': form})
