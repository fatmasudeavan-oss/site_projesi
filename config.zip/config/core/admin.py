from django.contrib import admin
from .models import *

admin.site.register(Block)
admin.site.register(Floor)
admin.site.register(Apartment)
admin.site.register(Resident)
admin.site.register(Announcement)
admin.site.register(Request)