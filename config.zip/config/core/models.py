from django.db import models

class Block(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name
    
class Floor(models.Model):
    block = models.ForeignKey(Block, on_delete=models.CASCADE)
    number = models.IntegerField()

    def __str__(self):
        return f"{self.block.name} - {self.number}. Kat"

class Apartment(models.Model):
    floor = models.ForeignKey(Floor, on_delete=models.CASCADE)
    number = models.CharField(max_length=10)

    def __str__(self):
        return self.number
    
class Resident(models.Model):
    apartment = models.ForeignKey(Apartment, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=20)

    def __str__(self):
        return self.name
    
class Announcement(models.Model):
    title = models.CharField(max_length=100)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
    
class Request(models.Model):
    resident = models.ForeignKey(Resident, on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    description = models.TextField()
    status = models.CharField(max_length=20, default="pending")

    def __str__(self):
        return self.title