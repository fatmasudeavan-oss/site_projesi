from django.contrib import admin
from django.urls import path
from core import views
from django.contrib.auth import views as auth_views
from core.views import register_view

urlpatterns = [
    path('admin/', admin.site.urls),

    path('', views.dashboard, name='dashboard'),

    path('blocks/', views.blocks_page, name='blocks'),
    path('apartments/', views.apartments_page, name='apartments'),
    path('apartments/delete/<int:id>/', views.apartment_delete, name='apartment_delete'),
    path('blocks/delete/<int:id>/', views.block_delete, name='block_delete'),
    path('residents/', views.residents_page, name='residents'),
    path('residents/delete/<int:id>/', views.resident_delete, name='resident_delete'),
    path('requests/', views.requests_page, name='requests'),
path('requests/delete/<int:id>/', views.request_delete, name='request_delete'),
path('requests/toggle/<int:id>/', views.request_toggle, name='request_toggle'),
# Giriş yapma yolu (HTML dosyası olmadan admin girişine yönlendirir)
   path("login/", views.login_view),
path("register/", views.register_view),
    
    # Çıkış yapma yolu
    
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),

    path('logout/', auth_views.LogoutView.as_view(next_page='/'), name='logout'),

    path('register/', register_view, name='register'),

    path(
    'logout/',
    auth_views.LogoutView.as_view(next_page='/'),
    name='logout'
),
    
  
  

]